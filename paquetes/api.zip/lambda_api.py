"""
La API de la plataforma. Un solo origen: todo esto se sirve en /api/* del mismo
dominio que la pagina, asi que el navegador no llama a nadie mas.

Como funciona el acceso, y por que asi:

  CONTRASENAS -> Cognito. Aqui no se guarda ningun hash: la politica de
  contrasenas, el cambio obligatorio del primer acceso y el cifrado son suyos.
  El NAVEGADOR NO HABLA CON COGNITO; si lo hiciera estaria llamando a
  cognito-idp.amazonaws.com, que es exactamente el dominio externo que no
  podemos usar. Habla con /api/acceso, y esta Lambda habla con Cognito desde
  dentro de AWS.

  SESION -> una fila nuestra con caducidad, y una cookie HttpOnly. No un JWT:
  con una fila propia se puede cerrar la sesion de alguien en el acto, y un
  token firmado no se puede retirar antes de que caduque.

  AMBITO -> el perfil sale de la sesion, nunca de la peticion.

Solo biblioteca estandar y boto3: nada que empaquetar.
"""

import datetime
import json
import os
import re
import secrets

import boto3

import autorizacion as A
import catalogo as CAT
import telemetria as TE
from comun import (abre_sesion, acota_de, borra, cabina_y_ambito, cierra_sesion, config, cookie_sesion,
                   cuerpo, delegaciones_de, escribe, lee, lista, lista_dias, panel_de, quien_es, r, s3,
                   BUCKET)

cog = boto3.client("cognito-idp")

POOL = os.environ.get("POOL", "")
CLIENTE = os.environ.get("CLIENTE_POOL", "")
# Los ficheros de telemetria que se suben desde la consola (docs/53). Es el UNICO
# sitio del bucket de datos en el que esta Lambda escribe.
EXTERNO = "externo/telemetria"
# Un listado de maquinas son cientos de KB. En base64 crece un tercio, y la
# peticion entera no puede pasar de los 6 MB que acepta una Lambda.
MAX_FICHERO = 3 * 1024 * 1024

INTENTOS_MAX = int(os.environ.get("INTENTOS_MAX", "6"))
MINUTOS_BLOQUEO = int(os.environ.get("MINUTOS_BLOQUEO", "15"))


# ----------------------------------------------------------------------
# freno a la fuerza bruta
# ----------------------------------------------------------------------
def _fallos(correo):
    """Los intentos fallidos que siguen contando.

    La caducidad se mira AQUI, con la hora que va dentro de la fila. El TTL de
    DynamoDB borra la fila cuando le viene bien, a veces horas despues; si se
    esperara a eso, «prueba en 15 minutos» podia ser media tarde. Una fila sin
    hora (de antes de este cambio) ya no cuenta.
    """
    import time
    fila = lee(f"FALLOS#{correo}", "CUENTA") or {}
    if int(fila.get("hasta", 0)) <= time.time():
        return 0
    return int(fila.get("n", 0))


def _suma_fallo(correo):
    import time
    n = _fallos(correo) + 1
    hasta = int(time.time()) + MINUTOS_BLOQUEO * 60
    escribe(f"FALLOS#{correo}", {"n": n, "hasta": hasta}, "CUENTA", expira=hasta)
    return n


def _limpia_fallos(correo):
    borra(f"FALLOS#{correo}", "CUENTA")


# ----------------------------------------------------------------------
# uso de la dashboard (docs/77)
# ----------------------------------------------------------------------
# Las paginas que se cuentan. Lo que llegue de otra ruta cuenta como «otra»:
# asi un Referer raro no llena la fila de claves inventadas.
PAGINAS = ("panel", "operativo", "cuadro", "rutas", "incidencias", "devoluciones", "furgonetas",
           "almacenes", "telemetria", "tarifas", "revision", "utilizo", "preferidos", "cifras",
           "consola", "avisos")
# Dos años largos, como el resto de historicos.
DIAS_USO = 800


def _ahora_espana():
    try:
        from zoneinfo import ZoneInfo
        return datetime.datetime.now(ZoneInfo("Europe/Madrid"))
    except Exception:  # noqa: BLE001  sin la base de zonas, la de UTC
        return datetime.datetime.utcnow()


def _apunta_uso(correo, entrada=False, pagina=None):
    """Suma a la fila del dia de esta persona una entrada o una pagina vista.

    Una fila por persona y dia (ACCESO#<correo>, sk = el dia en España). Si
    falla, se calla: contar el uso nunca puede tumbar la peticion que lo cuenta.
    """
    try:
        import time
        ahora = _ahora_espana()
        dia, hora = ahora.date().isoformat(), ahora.strftime("%H:%M")
        fila = lee(f"ACCESO#{correo}", dia) or {}
        if entrada:
            fila["entradas"] = int(fila.get("entradas", 0)) + 1
        if pagina:
            fila["vistas"] = int(fila.get("vistas", 0)) + 1
            paginas = fila.setdefault("paginas", {})
            paginas[pagina] = int(paginas.get(pagina, 0)) + 1
        fila.setdefault("primera", hora)
        fila["ultima"] = hora
        escribe(f"ACCESO#{correo}", fila, dia, expira=int(time.time()) + DIAS_USO * 86400)
    except Exception as e:  # noqa: BLE001
        print(f"USO no apuntado: {type(e).__name__}: {e}")


def _pagina_de(evento):
    """Que pagina de la dashboard ha pedido /api/yo, o None si no cuenta.

    Cada pagina pide /api/yo una vez al abrirse, y el navegador dice desde donde
    en el Referer. No cuentan: la portada de entrada («/»), las consultas que
    hace Vendi por dentro (su user-agent) ni la que hace el boton del asistente
    en cada pagina (lleva x-digivend-vista: no), que si no seria doble.
    """
    cab = {k.lower(): v for k, v in (evento.get("headers") or {}).items()}
    if "digivend-asistente" in cab.get("user-agent", "") or cab.get("x-digivend-vista") == "no":
        return None
    m = re.match(r"https?://[^/]+/([a-z]*)", cab.get("referer", ""))
    if not m or not m.group(1):
        return None
    return m.group(1) if m.group(1) in PAGINAS else "otra"


def uso_plataforma(dias=400):
    """Quien entra en la dashboard y cuanto, y quien pregunta a Vendi y cuanto gasta.

    Junta por persona y dia las filas ACCESO# (las escribe esta Lambda) y USO#
    (las escribe la del asistente). desde_web y desde_ia son el primer dia que
    hay de cada una: antes de eso no se contaba, y la pagina lo dice.
    """
    desde = (datetime.date.today() - datetime.timedelta(days=dias)).isoformat()
    nombres = {u["_id"]: u for u in lista("USUARIO#")}
    perfiles = {p["_id"]: p.get("nombre") or p["_id"] for p in lista("PERFIL#")}
    gente, desde_web, desde_ia = {}, None, None
    import time
    for pk, dia, dato, expira in lista_dias(["ACCESO#", "USO#"], desde):
        tipo, correo = pk.split("#", 1)
        if tipo == "USO" and expira and expira < time.time() + 400 * 86400:
            # Las filas de Vendi de antes de docs/77 caducaban a los 40 dias.
            # Se alargan aqui, la primera vez que alguien las mira, a los 800
            # desde su dia: es la unica Lambda que las lee todas.
            try:
                d0 = datetime.datetime.strptime(dia, "%Y-%m-%d").replace(tzinfo=datetime.timezone.utc)
                escribe(pk, dato, dia, expira=int(d0.timestamp()) + DIAS_USO * 86400)
            except Exception as e:  # noqa: BLE001
                print(f"USO no alargado: {type(e).__name__}: {e}")
        u = nombres.get(correo, {})
        quien = gente.setdefault(correo, {
            "correo": correo, "nombre": u.get("nombre", ""),
            "perfil": perfiles.get(u.get("perfil_id", ""), u.get("perfil_id", "")), "dias": {}})
        d = quien["dias"].setdefault(dia, {})
        if tipo == "ACCESO":
            desde_web = min(desde_web or dia, dia)
            for k in ("entradas", "vistas", "paginas", "primera", "ultima"):
                if k in dato:
                    d[k] = dato[k]
        else:
            desde_ia = min(desde_ia or dia, dia)
            d["preguntas"] = int(dato.get("preguntas", 0))
            d["gasto_usd"] = round(float(dato.get("gasto_usd", 0)), 4)
    return {"desde_web": desde_web, "desde_ia": desde_ia, "hoy": _ahora_espana().date().isoformat(),
            "usuarios": sorted(gente.values(), key=lambda x: x["correo"])}


# ----------------------------------------------------------------------
# entrada
# ----------------------------------------------------------------------
def lambda_handler(evento, contexto):
    http = evento.get("requestContext", {}).get("http", {})
    metodo = http.get("method", "GET")
    # API Gateway entrega el path limpio, pero una barra final de mas convertiria
    # una ruta buena en un 404 sin que nadie entienda por que.
    ruta = (http.get("path") or "/").split("?")[0].rstrip("/") or "/"
    cab = {k.lower(): v for k, v in (evento.get("headers") or {}).items()}

    # Una escritura que venga de otro sitio no entra. Con la cookie en
    # SameSite=Strict el navegador ya no la manda; esto lo confirma donde el
    # propio navegador lo declara.
    if metodo not in ("GET", "HEAD") and cab.get("sec-fetch-site") not in (None, "same-origin"):
        return r(403, {"error": "Peticion de otro origen."})

    try:
        return encamina(evento, metodo, ruta)
    except PermissionError as e:
        return r(403, {"error": str(e) or "Sin permiso."})
    except ValueError as e:
        return r(400, {"error": str(e)})
    except Exception as e:  # noqa: BLE001
        print(f"ERROR {metodo} {ruta}: {type(e).__name__}: {e}")
        return r(500, {"error": "Error interno."})


def encamina(evento, metodo, ruta):
    # ---------------------------------------------------- publico
    if ruta == "/api/acceso" and metodo == "POST":
        return acceso(evento)
    if ruta == "/api/acceso/nueva-clave" and metodo == "POST":
        return nueva_clave(evento)

    # ---------------------------------------------------- hace falta sesion
    sesion = quien_es(evento)
    if not sesion:
        return r(401, {"error": "Sin sesion."})
    usuario, perfil = sesion["usuario"], sesion["perfil"]
    # Lo que el administrador le quito a este usuario dentro de su perfil
    # (docs/61): cuadrados y tablas. Desde aqui, cada regla que mira el perfil
    # mira ya el del usuario.
    perfil = A.con_usuario(perfil, usuario)
    c = config()
    permisos = A.permisos_efectivos(perfil, usuario, c)

    if ruta == "/api/salir" and metodo == "POST":
        cierra_sesion(sesion["token"])
        return r(200, {"ok": True}, [cookie_sesion("")])

    if ruta == "/api/yo":
        pagina = _pagina_de(evento)
        if pagina:
            _apunta_uso(usuario["correo"], pagina=pagina)
        ok_ia, motivo = A.asistente_habilitado(c, perfil, usuario)
        return r(200, {
            "correo": usuario["correo"],
            "nombre": usuario.get("nombre", ""),
            "tipo": perfil.get("tipo", "cliente"),
            "perfil": perfil.get("nombre") or perfil.get("perfil_id", ""),
            "perfil_id": perfil.get("perfil_id", ""),
            "sesiones": sesiones_visibles(perfil),
            "catalogo_sesiones": {k: v[0] for k, v in A.SESIONES.items()},
            # Que partes del cuadro ve, y que datos le llegan para ellas.
            "cuadro": {"secciones": A.secciones_cuadro(perfil),
                       "flujos": A.flujos_cuadro(perfil)},
            # Los cuadrados del informe operativo que ve, y lo que no ve dentro
            # de la pagina de cada uno (docs/61).
            "cuadrados": A.cuadrados_de(perfil)
            if A.nivel_de(perfil.get("tipo", "cliente")) >= A.NIVEL["operaciones"] else [],
            "tablas_ocultas": perfil.get("tablas_ocultas") or {},
            # Los paneles de /panel/ que su perfil no ve (docs/63).
            "paneles_ocultos": A.paneles_ocultos(perfil),
            "permisos": permisos,
            "asistente": {"habilitado": ok_ia, "motivo": motivo},
            "umbral": perfil.get("reglas_negocio", {}).get(
                "umbral_rentabilidad_mes", c["umbral_rentabilidad_mes"]),
        })

    if ruta == "/api/panel":
        p = panel_de(_cabina(perfil))
        if p is None:
            return r(503, {"error": "El panel todavia no se ha calculado.",
                           "_nota": "Los agregados corren a las 4:45; recien desplegado, lanzalos a mano."})
        return r(200, A.recorta(p, perfil))

    # El cuadro de mando: el indice, o el fichero de un mes. Igual que el panel,
    # la carpeta sale del perfil de la sesion; lo unico que se pide es QUE mes, y
    # se valida contra la lista del propio indice antes de tocar S3.
    if ruta == "/api/cuadro" and metodo == "GET":
        if "cuadro" not in A.sesiones_de(perfil.get("tipo", "cliente"), perfil.get("sesiones", [])):
            raise PermissionError("Este perfil no tiene el cuadro de mando.")
        q = evento.get("queryStringParameters") or {}
        # Se mira si el parametro VIENE, no si trae algo: con `or`, un mes vacio
        # se colaba como «dame el indice» en vez de darse por no valido.
        # «trozo» es el nombre que uso la version de meses troceados.
        return cuadro(perfil, q["mes"] if "mes" in q else q.get("trozo"))

    # La serie diaria: el indice de meses, o un mes. Es lo que permite pedir hoy,
    # ayer, este mes, el mes pasado o un intervalo cualquiera desde 2025 sin que
    # la pagina tenga que bajarse la historia entera.
    if ruta == "/api/serie" and metodo == "GET":
        q = evento.get("queryStringParameters") or {}
        if "centros" in q:
            return serie_centros(perfil, q["centros"])
        return serie(perfil, q.get("mes"))

    # El informe general operativo (docs/51): los cuadrados de los ultimos dias.
    # Como el panel, el fichero es el del perfil de la sesion y no hay nada que
    # pedir: ni perfil ni dia. La pagina elige el dia entre los que llegan.
    if ruta == "/api/operativo" and metodo == "GET":
        if A.nivel_de(perfil.get("tipo", "cliente")) < A.NIVEL["operaciones"]:
            raise PermissionError("Un perfil de cliente solo tiene el cuadro de mando.")
        q = evento.get("queryStringParameters") or {}
        if "centros" in q:
            return operativo_centros(perfil, q["centros"])
        if "mes" in q:
            return operativo_mes(perfil, q["mes"])
        # Con toda la historia va comprimido (docs/66); el de antes, sin
        # comprimir, vale mientras la noche no haya escrito el nuevo.
        datos = None
        for clave in ("operativo.json.gz", "operativo.json"):
            try:
                datos = json.loads(_crudo(f"cabina/{_cabina(perfil)}/{clave}"))
                break
            except Exception:
                continue
        if datos is None:
            return r(503, {"error": "El informe operativo todavia no se ha calculado.",
                           "_nota": "Lo escriben los agregados cada noche (4:45)."})
        # Solo las fichas de los centros y el area de cada delegacion: lo que
        # llena los filtros de las secciones (docs/73), sin la historia.
        if "fichas" in q:
            return r(200, A.fichas_operativo(datos))
        return _json_grande(A.recorta_operativo(datos, perfil))

    # Tarifas contra venta real (docs/52): el resumen del perfil, o un centro.
    # El centro no abre la puerta a otro perfil: el fichero se busca DENTRO del
    # perfil de la sesion, y solo si su resumen de esta noche lo cita.
    if ruta == "/api/tarifas" and metodo == "GET":
        if "tarifas" not in A.cuadrados_de(perfil) or \
                A.nivel_de(perfil.get("tipo", "cliente")) < A.NIVEL["operaciones"]:
            raise PermissionError("Este perfil no tiene el cuadrado de tarifas.")
        q = evento.get("queryStringParameters") or {}
        return tarifas(perfil, q.get("centro") if "centro" in q else None)

    # La pagina de telemetria (docs/53): maquina a maquina, de las del perfil.
    # La misma regla que el cuadrado que lleva a ella: si no lo ve, no la ve.
    if ruta == "/api/telemetria" and metodo == "GET":
        if A.nivel_de(perfil.get("tipo", "cliente")) < A.NIVEL["operaciones"]:
            raise PermissionError("Un perfil de cliente solo tiene el cuadro de mando.")
        if "telemetria" not in A.cuadrados_de(perfil):
            raise PermissionError("Este perfil no ve la telemetría.")
        try:
            return _como_json(_crudo(f"cabina/{_cabina(perfil)}/telemetria.json"))
        except Exception:
            return r(503, {"error": "Todavía no hay cruce de telemetría: sube los ficheros de "
                                    "Nayax, Prodelfi y Nebula en la consola y espera a la noche.",
                           "_nota": "Lo escriben los agregados cada noche (4:45)."})

    # La pagina de rutas (docs/55): delegaciones, rutas y puntos de venta del
    # perfil. La misma regla que el cuadrado que lleva a ella.
    if ruta == "/api/rutas" and metodo == "GET":
        if A.nivel_de(perfil.get("tipo", "cliente")) < A.NIVEL["operaciones"]:
            raise PermissionError("Un perfil de cliente solo tiene el cuadro de mando.")
        if "rutas" not in A.cuadrados_de(perfil):
            raise PermissionError("Este perfil no ve las rutas.")
        q = evento.get("queryStringParameters") or {}
        if "mes" in q:
            return mes_de_seccion(perfil, "rutas", "rutas", q["mes"])
        try:
            return _con_tablas("rutas", perfil, _crudo(f"cabina/{_cabina(perfil)}/rutas.json.gz"))
        except Exception:
            return r(503, {"error": "Las rutas todavía no se han calculado.",
                           "_nota": "Lo escriben los agregados cada noche (4:45)."})

    # La pagina de furgonetas (docs/58): vehiculo a vehiculo, del perfil. La
    # misma regla que el cuadrado que lleva a ella.
    if ruta == "/api/furgonetas" and metodo == "GET":
        if A.nivel_de(perfil.get("tipo", "cliente")) < A.NIVEL["operaciones"]:
            raise PermissionError("Un perfil de cliente solo tiene el cuadro de mando.")
        if "furgonetas" not in A.cuadrados_de(perfil):
            raise PermissionError("Este perfil no ve las furgonetas.")
        q = evento.get("queryStringParameters") or {}
        if "mes" in q:
            return mes_de_seccion(perfil, "furgonetas", "furgonetas", q["mes"])
        try:
            return _con_tablas("furgonetas", perfil,
                               _crudo(f"cabina/{_cabina(perfil)}/furgonetas.json.gz"))
        except Exception:
            return r(503, {"error": "Las furgonetas todavía no se han calculado.",
                           "_nota": "Lo escriben los agregados cada noche (4:45)."})

    # La pagina de incidencias (docs/56): las de la SAT del perfil de la sesion.
    # La misma regla que el cuadrado de Incidencias que lleva a ella. Se sirve
    # comprimido tal cual esta en S3: con un ano de incidencias del interno
    # pasaria del limite de respuesta de una Lambda si se descomprimiera.
    if ruta == "/api/incidencias" and metodo == "GET":
        if A.nivel_de(perfil.get("tipo", "cliente")) < A.NIVEL["operaciones"]:
            raise PermissionError("Un perfil de cliente solo tiene el cuadro de mando.")
        if "averias" not in A.cuadrados_de(perfil):
            raise PermissionError("Este perfil no ve las incidencias.")
        try:
            comprimido = s3.get_object(Bucket=BUCKET, Key=f"cabina/{_cabina(perfil)}/"
                                                           "incidencias.json.gz")["Body"].read()
        except Exception:
            return r(503, {"error": "Las incidencias todavía no se han calculado.",
                           "_nota": "Lo escriben los agregados cada noche (4:45)."})
        return _con_tablas("averias", perfil, comprimido)

    # La revision de clientes (docs/59): las maquinas del perfil con lo que
    # tienen mal configurado. La misma regla que el cuadrado que lleva a ella.
    # Comprimido tal cual: los productos del interno son varios megas.
    if ruta == "/api/revision" and metodo == "GET":
        if A.nivel_de(perfil.get("tipo", "cliente")) < A.NIVEL["operaciones"]:
            raise PermissionError("Un perfil de cliente solo tiene el cuadro de mando.")
        if "revision" not in A.cuadrados_de(perfil):
            raise PermissionError("Este perfil no ve la revisión de clientes.")
        try:
            comprimido = s3.get_object(Bucket=BUCKET, Key=f"cabina/{_cabina(perfil)}/"
                                                           "revision.json.gz")["Body"].read()
        except Exception:
            return r(503, {"error": "La revisión de clientes todavía no se ha calculado.",
                           "_nota": "Lo escriben los agregados cada noche (4:45)."})
        return _con_tablas("revision", perfil, comprimido)

    # Utilizo, la dashboard y Vendi (docs/77): quien entra, cuanto, y cuanto
    # gasta en el asistente. Lo ve quien ve el cuadrado Utilizo, nadie mas.
    if ruta == "/api/utilizo/plataforma" and metodo == "GET":
        if "utilizo" not in A.cuadrados_de(perfil):
            raise PermissionError("Este perfil no ve el uso de la plataforma.")
        return r(200, uso_plataforma())

    # Utilizo (docs/60): cuanto usa VenCloud cada persona. Solo se escribe a
    # los perfiles sin ambito, y solo lo pide quien ve su cuadrado.
    if ruta == "/api/utilizo" and metodo == "GET":
        if "utilizo" not in A.cuadrados_de(perfil):
            raise PermissionError("Este perfil no ve el uso de VenCloud.")
        try:
            comprimido = s3.get_object(Bucket=BUCKET, Key=f"cabina/{_cabina(perfil)}/"
                                                           "utilizo.json.gz")["Body"].read()
        except Exception:
            return r(503, {"error": "El uso de VenCloud todavía no se ha calculado.",
                           "_nota": "Lo escriben los agregados cada noche (4:45)."})
        return _comprimido(comprimido)

    # La pagina de devoluciones (docs/57): igual que la de incidencias, de la
    # misma foto, con su propio cuadrado.
    if ruta == "/api/devoluciones" and metodo == "GET":
        if A.nivel_de(perfil.get("tipo", "cliente")) < A.NIVEL["operaciones"]:
            raise PermissionError("Un perfil de cliente solo tiene el cuadro de mando.")
        if "devoluciones" not in A.cuadrados_de(perfil):
            raise PermissionError("Este perfil no ve las devoluciones.")
        try:
            comprimido = s3.get_object(Bucket=BUCKET, Key=f"cabina/{_cabina(perfil)}/"
                                                           "devoluciones.json.gz")["Body"].read()
        except Exception:
            return r(503, {"error": "Las devoluciones todavía no se han calculado.",
                           "_nota": "Lo escriben los agregados cada noche (4:45)."})
        return _con_tablas("devoluciones", perfil, comprimido)

    # Los almacenes por dentro (docs/54): el fichero del perfil, y la foto de un
    # producto. Quien ve el cuadrado de almacenes ve la pagina; la foto solo si
    # el fichero de SU perfil cita ese producto con foto.
    if ruta in ("/api/almacenes", "/api/almacenes/foto") and metodo == "GET":
        if "almacenes" not in A.cuadrados_de(perfil):
            raise PermissionError("Este perfil no tiene el cuadrado de almacenes.")
        q = evento.get("queryStringParameters") or {}
        return almacenes(perfil, q.get("art", "") if ruta.endswith("/foto") else None)

    # El orden lo elige el usuario y se guarda en el SERVIDOR: asi lo encuentra
    # igual desde otro ordenador. El navegador no es el sitio donde vive.
    if ruta == "/api/orden":
        clave = f"PREF#{usuario['correo']}"
        if metodo == "GET":
            return r(200, lee(clave, "ORDEN") or {"orden": []})
        if metodo == "PUT":
            if not permisos.get("reordenar"):
                raise PermissionError("Este perfil no puede reordenar los paneles.")
            orden = cuerpo(evento).get("orden")
            if not isinstance(orden, list) or len(orden) > 64:
                raise ValueError("Orden no valido.")
            escribe(clave, {"orden": [str(x)[:40] for x in orden]}, "ORDEN")
            return r(200, {"ok": True})

    # Las tablas y graficos con estrella (docs/62): de cada usuario, en el
    # servidor como el orden, para que los encuentre igual desde otro ordenador.
    # Solo se guardan y se devuelven las que puede ver hoy.
    if ruta == "/api/preferidos":
        if A.nivel_de(perfil.get("tipo", "cliente")) < A.NIVEL["operaciones"]:
            raise PermissionError("Un perfil de cliente solo tiene el cuadro de mando.")
        clave = f"PREF#{usuario['correo']}"
        if metodo == "GET":
            guardados = (lee(clave, "PREFERIDOS") or {}).get("preferidos")
            return r(200, {"preferidos": A.preferidos_validos(guardados, perfil),
                           "nombres": {c: {"nombre": A.NOMBRE_CUADRADO[c], "tablas": dict(A.TABLAS[c])}
                                       for c in A.cuadrados_de(perfil) if c in A.TABLAS}})
        if metodo == "PUT":
            lista_ = cuerpo(evento).get("preferidos")
            if not isinstance(lista_, list) or len(lista_) > 4 * A.MAX_PREFERIDOS:
                raise ValueError("Preferidos no validos.")
            buenos = A.preferidos_validos(lista_, perfil)
            escribe(clave, {"preferidos": buenos}, "PREFERIDOS")
            return r(200, {"preferidos": buenos})

    # El catalogo lo sirve la API para que el formulario del navegador no lleve
    # una copia que se quede vieja en cuanto alguien anada una fuente.
    if ruta == "/api/catalogo-alarmas" and metodo == "GET":
        if not permisos.get("alarmas_ver"):
            raise PermissionError("Este perfil no ve las alarmas.")
        return r(200, {"catalogo": CAT.para_el_navegador()})

    if ruta == "/api/alarmas":
        if metodo == "GET":
            if not permisos.get("alarmas_ver"):
                raise PermissionError("Este perfil no ve las alarmas.")
            return r(200, {"alarmas": lista("ALARMA#"), "avisos": lista("AVISO#")[-100:]})
        if metodo == "POST":
            if not permisos.get("alarmas_crear"):
                raise PermissionError("Este perfil no puede crear alarmas.")
            return guarda_alarma(evento, usuario)

    if ruta.startswith("/api/alarmas/") and metodo == "DELETE":
        if not permisos.get("alarmas_crear"):
            raise PermissionError("Este perfil no puede borrar alarmas.")
        borra("ALARMA#" + ruta.rsplit("/", 1)[-1])
        return r(200, {"ok": True})

    if ruta == "/api/whatsapp" and metodo == "POST":
        if not permisos.get("whatsapp"):
            raise PermissionError("Este perfil no puede enviar WhatsApp.")
        return encola(evento, usuario, "whatsapp")

    if ruta == "/api/incidencia" and metodo == "POST":
        if not permisos.get("incidencia"):
            raise PermissionError("Este perfil no puede abrir incidencias.")
        return encola(evento, usuario, "incidencia")

    if ruta == "/api/estado-carga":
        if perfil.get("tipo") != "admin":
            raise PermissionError("Solo el administrador.")
        try:
            b = s3.get_object(Bucket=BUCKET, Key="cabina/_estado/carga.json")["Body"].read()
            return r(200, json.loads(b))
        except Exception:
            return r(200, {"_nota": "Todavia no hay ninguna carga registrada."})

    # ---------------------------------------------------- administracion
    if ruta.startswith("/api/admin/"):
        if perfil.get("tipo") != "admin":
            raise PermissionError("Solo el administrador.")
        return administra(evento, metodo, ruta, usuario)

    return r(404, {"error": "No existe esa ruta."})


# ----------------------------------------------------------------------
# el cuadro de mando
# ----------------------------------------------------------------------
def _cabina(perfil):
    """La carpeta de cabina/ de la sesion: la de su perfil o, si el usuario
    tiene delegaciones, la suya (comun.cabina_y_ambito, docs/65)."""
    return perfil.get("cabina") or perfil.get("perfil_id", "")


def _crudo(clave):
    """El fichero de S3 tal cual, descomprimido si viene comprimido.

    Un mes de venta son un par de MB: leerlo como JSON y volver a escribirlo
    solo gastaria memoria y tiempo de una Lambda de 512 MB para devolver lo
    mismo. Los meses se guardan comprimidos —un mes de AIRBUS pasa de tres
    megas a unos cuatrocientos kilos—, asi que lo unico que se hace es
    descomprimirlos.
    """
    cuerpo = s3.get_object(Bucket=BUCKET, Key=clave)["Body"].read()
    if cuerpo[:2] == b"\x1f\x8b":
        import gzip
        cuerpo = gzip.decompress(cuerpo)
    return cuerpo


def _comprimido(cuerpo):
    """Un JSON que ya esta comprimido en S3, sin abrirlo: el navegador lo abre."""
    import base64
    if cuerpo[:2] != b"\x1f\x8b":
        return _como_json(cuerpo)
    return {"statusCode": 200,
            "headers": {"content-type": "application/json; charset=utf-8",
                        "content-encoding": "gzip", "cache-control": "no-store"},
            "isBase64Encoded": True,
            "body": base64.b64encode(cuerpo).decode("ascii")}


def _con_tablas(cuadrado, perfil, cuerpo):
    """El fichero de la pagina de un cuadrado, sin lo que solo usan las tablas
    que el administrador le quito a este usuario (docs/61).

    Sin nada que quitar, sale tal cual, comprimido o no, como hasta ahora: ni
    se abre. Con algo, se abre, se recorta y se vuelve a comprimir si venia
    comprimido.
    """
    import gzip
    comprimido = cuerpo[:2] == b"\x1f\x8b"
    if not A.hay_recorte(cuadrado, perfil):
        return _comprimido(cuerpo) if comprimido else _como_json(cuerpo)
    datos = json.loads(gzip.decompress(cuerpo) if comprimido else cuerpo)
    texto = json.dumps(A.recorta_tablas(cuadrado, datos, perfil),
                       ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    return _comprimido(gzip.compress(texto)) if comprimido else _como_json(texto)


def _como_json(cuerpo):
    return {"statusCode": 200,
            "headers": {"content-type": "application/json; charset=utf-8",
                        "cache-control": "no-store"},
            "body": cuerpo.decode("utf-8")}


def _mes_valido(indice, mes):
    """Un mes que el indice de ese perfil cite, y nada mas.

    Asi no hay forma de componer otra clave: ni de otro mes inventado, ni —lo
    que importa— de otro perfil. El nombre no se concatena hasta despues de
    encontrarlo en la lista.
    """
    meses = [str(m.get("mes")) for m in (json.loads(indice).get("meses") or [])]
    if str(mes) not in meses:
        raise ValueError("Ese mes no existe en este cuadro.")
    return str(mes)


def _hay_cuadro(perfil_id):
    """Si el cuadro de este perfil esta calculado: una cabecera, nada mas."""
    if not perfil_id:
        return False
    try:
        s3.head_object(Bucket=BUCKET, Key=f"cabina/{perfil_id}/cuadro/indice.json")
        return True
    except Exception:
        return False


def sesiones_visibles(perfil):
    """Las sesiones que se ensenan, sin el cuadro si el perfil no lo tiene.

    El administrador ve todas las sesiones sin que nadie se las conceda, y el
    cuadro solo se calcula para los perfiles de cliente (los que tienen
    ambito). Con el perfil interno, el boton «Cuadro de mando» llevaba a una
    pagina que decia que no se habia calculado, y la entrada le mandaba alli
    a quien lo tuviera. Lo que no existe no se ofrece. /api/cuadro sigue
    contestando 503 a quien lo pida a mano.
    """
    sesiones = A.sesiones_de(perfil.get("tipo", "cliente"), perfil.get("sesiones", []))
    if "cuadro" in sesiones and not _hay_cuadro(_cabina(perfil)):
        sesiones.remove("cuadro")
    return sesiones


def cuadro(perfil, mes=None):
    """El indice del cuadro, o el fichero de un mes, con lo que el perfil ve.

    Si el perfil ve todas las secciones, el fichero sale tal cual, sin leerlo
    como JSON. Si se le ha quitado alguna, se quitan del fichero los flujos
    que ya no necesita (docs/49): ocultar la seccion en la pagina no basta,
    porque el dato seguiria llegando al navegador.
    """
    base = f"cabina/{_cabina(perfil)}/cuadro/"
    entero = A.flujos_cuadro(perfil) == list(A.TODOS_FLUJOS)
    try:
        indice = _crudo(base + "indice.json")
    except Exception:
        return r(503, {"error": "El cuadro de mando todavia no se ha calculado.",
                       "_nota": "Lo escriben los agregados (4:45) para cada perfil de "
                                "cliente con ambito."})
    if mes is None:
        if entero:
            return _como_json(indice)
        return r(200, A.recorta_cuadro_indice(json.loads(indice), perfil))
    fichero = _crudo(f"{base}mes-{_mes_valido(indice, mes)}.json.gz")
    if entero:
        return _como_json(fichero)
    return r(200, A.recorta_cuadro_mes(json.loads(fichero), perfil))


def serie(perfil, mes=None):
    """La serie diaria del perfil de la sesion: el indice de meses, o un mes.

    El recorte es el mismo que el del panel y por lo mismo: una fila de la serie
    lleva los mismos bloques —servicio, dinero, sat, jornadas—, asi que un
    perfil que no ve el dinero en el panel tampoco puede verlo aqui dia a dia.
    Si no se recortara, la serie seria la puerta de atras del panel.
    """
    base = f"cabina/{_cabina(perfil)}/serie/"
    try:
        indice = _crudo(base + "indice.json")
    except Exception:
        return r(503, {"error": "El historico todavia no se ha calculado.",
                       "_nota": "Lo escriben los agregados cada noche; la historia "
                                "anterior se rellena a mano una vez."})
    if mes is None:
        return r(200, indice_serie_visible(json.loads(indice), perfil))
    mes = _mes_valido(indice, mes)
    datos = json.loads(_crudo(f"{base}{mes}.json.gz"))
    return r(200, {"mes": mes,
                   "filas": [A.recorta_dia(f, perfil) for f in datos.get("filas", [])]})


def tarifas(perfil, centro=None):
    """El resumen de tarifas del perfil de la sesion, o el detalle de un centro."""
    base = f"cabina/{_cabina(perfil)}/tarifas/"
    try:
        resumen = _crudo(base + "resumen.json.gz")
    except Exception:
        return r(503, {"error": "Las tarifas todavía no se han calculado: falta el maestro "
                                "de tarifas (M10 · EXT_MAESTRO_TARIFAS) o la carga de esta noche.",
                       "_nota": "Lo escriben los agregados cada noche (4:45)."})
    if centro is None:
        return _como_json(resumen)
    citados = {str(c.get("num_centro")) for d in json.loads(resumen).get("delegaciones", [])
               for c in d.get("centros", [])}
    if not str(centro).isdigit() or str(centro) not in citados:
        raise ValueError("Ese centro no está en las tarifas de este perfil.")
    return _como_json(_crudo(f"{base}centros/{centro}.json.gz"))


CODIGO_ARTICULO = re.compile(r"[A-Za-z0-9._-]{1,40}")


def almacenes(perfil, art=None):
    """Los almacenes del perfil de la sesion, o la foto de uno de sus productos."""
    try:
        cuerpo = _crudo(f"cabina/{_cabina(perfil)}/almacenes.json.gz")
    except Exception:
        return r(503, {"error": "Los almacenes todavía no se han calculado.",
                       "_nota": "Lo escriben los agregados cada noche (4:45)."})
    if art is None:
        return _json_grande(json.loads(cuerpo))
    art = str(art)
    if not CODIGO_ARTICULO.fullmatch(art):
        raise ValueError("Ese código de artículo no es válido.")
    citadas = {p.get("cod") for a in json.loads(cuerpo).get("almacenes", [])
               for p in a.get("productos", []) if p.get("foto")}
    if art not in citadas:
        return r(404, {"error": "Ese producto no tiene foto en los almacenes de este perfil."})
    try:
        obj = s3.get_object(Bucket=BUCKET, Key=f"cabina/_articulos/fotos/{art}")
    except Exception:
        return r(404, {"error": "La foto todavía no se ha guardado."})
    import base64
    return {"statusCode": 200,
            "headers": {"content-type": obj.get("ContentType") or "image/jpeg",
                        # Es de la sesion, pero no cambia en el dia.
                        "cache-control": "private, max-age=86400"},
            "isBase64Encoded": True,
            "body": base64.b64encode(obj["Body"].read()).decode("ascii")}


def ve_delegaciones(perfil):
    """La delegacion es organizacion interna de Serunion: un cliente no la ve,
    ni como filtro ni en la ficha de sus centros."""
    return A.nivel_de(perfil.get("tipo", "cliente")) >= A.NIVEL["operaciones"]


def indice_serie_visible(indice, perfil):
    """El indice de la serie como lo puede ver este perfil.

    Las fichas de los centros llevan cliente y delegacion para poder filtrar.
    Un perfil de cliente se queda sin la delegacion: no es suya, es nuestra.
    Los centros que salen son solo los de su serie, que ya se calculo con su
    ambito: no hay forma de ver un centro de otro.
    """
    interno = ve_delegaciones(perfil)
    indice = dict(indice)
    indice["centros"] = {k: {c: x for c, x in (v or {}).items()
                             if interno or c != "delegacion"}
                         for k, v in (indice.get("centros") or {}).items()}
    indice["filtros"] = ["delegacion", "cliente", "centro"] if interno else ["cliente", "centro"]
    return indice


def serie_centros(perfil, mes):
    """El mismo dia partido por centro, para el filtro de delegacion, cliente y
    centro. Con la misma tijera que la fila del dia, centro a centro."""
    base = f"cabina/{_cabina(perfil)}/serie/"
    try:
        indice = json.loads(_crudo(base + "indice.json"))
    except Exception:
        return r(503, {"error": "El historico todavia no se ha calculado."})
    if str(mes) not in [str(m) for m in (indice.get("meses_centros") or [])]:
        raise ValueError("Ese mes no tiene el reparto por centro.")
    mes = str(mes)
    datos = json.loads(_crudo(f"{base}centros-{mes}.json.gz"))
    filas = []
    for f in datos.get("filas", []):
        centros = {}
        for clave, c in (f.get("centros") or {}).items():
            x = A.recorta_dia(dict(c, f=None), perfil)
            x.pop("f", None)
            if x:
                centros[clave] = x
        filas.append({"f": f.get("f"), "centros": centros})
    return _json_grande({"mes": mes, "filas": filas})


def operativo_centros(perfil, mes):
    """Un mes del informe general partido por centro, para el filtro de cliente
    y centro (docs/72). Dentro de la carpeta de la sesion, como todo: no hay
    con que pedir el de otro perfil. El mes es AAAA-MM y nada mas."""
    mes = str(mes or "")
    if not re.fullmatch(r"\d{4}-\d{2}", mes):
        raise ValueError("El mes va como AAAA-MM.")
    try:
        datos = json.loads(_crudo(f"cabina/{_cabina(perfil)}/operativo/centros-{mes}.json.gz"))
    except Exception:
        return r(404, {"error": "Ese mes no tiene el reparto por centro."})
    return _json_grande(A.recorta_operativo_centros(datos, perfil))


def mes_de_seccion(perfil, cuadrado, carpeta, mes):
    """Un mes de la historia de la pagina de una seccion (docs/79), de
    <carpeta>/dias-AAAA-MM. Dentro de la carpeta de la sesion, el mes es
    AAAA-MM y nada mas, y sin lo que solo usan las tablas que se le quitaron."""
    mes = str(mes or "")
    if not re.fullmatch(r"\d{4}-\d{2}", mes):
        raise ValueError("El mes va como AAAA-MM.")
    try:
        cuerpo = s3.get_object(Bucket=BUCKET, Key=f"cabina/{_cabina(perfil)}/{carpeta}/"
                                                  f"dias-{mes}.json.gz")["Body"].read()
    except Exception:
        return r(404, {"error": "Ese mes no tiene días calculados."})
    return _con_tablas(cuadrado, perfil, cuerpo)


def operativo_mes(perfil, mes):
    """Un mes de la historia del informe general (docs/79): los dias de antes de
    los que lleva el fichero del perfil. Dentro de la carpeta de la sesion, y el
    mes es AAAA-MM y nada mas."""
    mes = str(mes or "")
    if not re.fullmatch(r"\d{4}-\d{2}", mes):
        raise ValueError("El mes va como AAAA-MM.")
    try:
        datos = json.loads(_crudo(f"cabina/{_cabina(perfil)}/operativo/dias-{mes}.json.gz"))
    except Exception:
        return r(404, {"error": "Ese mes no tiene días calculados."})
    return _json_grande(A.recorta_operativo_mes(datos, perfil))


def _json_grande(datos):
    """Una respuesta que puede pasar del limite de una Lambda (6 MB): por encima
    de 1 MB va comprimida, y el navegador la descomprime solo. El mes del
    interno partido por centro es la que lo necesita."""
    cuerpo = json.dumps(datos, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    cabeceras = {"content-type": "application/json; charset=utf-8", "cache-control": "no-store"}
    if len(cuerpo) <= 1_000_000:
        return {"statusCode": 200, "headers": cabeceras, "body": cuerpo.decode("utf-8")}
    import base64
    import gzip
    return {"statusCode": 200, "headers": dict(cabeceras, **{"content-encoding": "gzip"}),
            "isBase64Encoded": True,
            "body": base64.b64encode(gzip.compress(cuerpo)).decode("ascii")}


# ----------------------------------------------------------------------
# acceso
# ----------------------------------------------------------------------
def acceso(evento):
    d = cuerpo(evento)
    correo = str(d.get("correo", "")).strip().lower()
    clave = str(d.get("clave", ""))
    if not correo or not clave:
        raise ValueError("Falta el correo o la contrasena.")

    if _fallos(correo) >= INTENTOS_MAX:
        return r(429, {"error": f"Demasiados intentos. Prueba en {MINUTOS_BLOQUEO} minutos."})

    try:
        res = cog.admin_initiate_auth(
            UserPoolId=POOL, ClientId=CLIENTE,
            AuthFlow="ADMIN_USER_PASSWORD_AUTH",
            AuthParameters={"USERNAME": correo, "PASSWORD": clave},
        )
    except (cog.exceptions.NotAuthorizedException,
            cog.exceptions.UserNotFoundException):
        _suma_fallo(correo)
        # Mismo texto en los dos casos: no se dice si la cuenta existe.
        return r(401, {"error": "Correo o contrasena incorrectos."})

    if res.get("ChallengeName") == "NEW_PASSWORD_REQUIRED":
        # Primer acceso: la contrasena que puso el admin es de un solo uso.
        return r(200, {"cambio_requerido": True, "reto": res["Session"], "correo": correo})

    if not lee(f"USUARIO#{correo}"):
        return r(403, {"error": "La cuenta no esta configurada. Avisa al administrador."})

    _limpia_fallos(correo)
    _apunta_uso(correo, entrada=True)
    return r(200, {"ok": True}, [cookie_sesion(abre_sesion(correo))])


def nueva_clave(evento):
    d = cuerpo(evento)
    correo = str(d.get("correo", "")).strip().lower()
    reto, clave = str(d.get("reto", "")), str(d.get("clave", ""))
    if not (correo and reto and clave):
        raise ValueError("Faltan datos para cambiar la contrasena.")
    try:
        cog.admin_respond_to_auth_challenge(
            UserPoolId=POOL, ClientId=CLIENTE,
            ChallengeName="NEW_PASSWORD_REQUIRED", Session=reto,
            ChallengeResponses={"USERNAME": correo, "NEW_PASSWORD": clave},
        )
    except cog.exceptions.InvalidPasswordException:
        raise ValueError("La contrasena no cumple la politica: 12 caracteres, "
                         "con mayuscula, minuscula y numero.") from None
    except Exception:
        raise ValueError("No se ha podido cambiar la contrasena. Vuelve a entrar.") from None
    # La misma comprobacion que en /api/acceso, y por lo mismo: una cuenta de
    # Cognito sin ficha no es un usuario de la plataforma. Sin esto, quien
    # llegara aqui sin ficha se gastaba su clave de un solo uso, recibia una
    # cookie buena y luego se encontraba un 401 en todas las pantallas, sin
    # entender por que. Ahora lo lee antes de gastar nada.
    if not lee(f"USUARIO#{correo}"):
        return r(403, {"error": "La cuenta no esta configurada. Avisa al administrador."})

    _limpia_fallos(correo)
    _apunta_uso(correo, entrada=True)
    return r(200, {"ok": True}, [cookie_sesion(abre_sesion(correo))])


# ----------------------------------------------------------------------
# acciones hacia fuera
# ----------------------------------------------------------------------
def encola(evento, usuario, tipo):
    """WhatsApp y altas de incidencia se dejan en cola; las envia la de alarmas.

    Encolar en vez de enviar aqui tiene dos razones: si el proveedor tarda o
    falla, quien pulso el boton no se queda esperando y el mensaje no se pierde;
    y un alta en VenCloud es una ESCRITURA en el ERP, asi que queda registrado
    quien la pidio.
    """
    d = cuerpo(evento)
    ident = secrets.token_hex(8)
    fila = {"tipo": tipo, "pedido_por": usuario["correo"],
            "cuando": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            "estado": "en_cola"}

    if tipo == "whatsapp":
        destino = str(d.get("empleado_id") or d.get("telefono") or "").strip()
        texto = str(d.get("texto", "")).strip()
        if not destino or not texto:
            raise ValueError("Falta el destinatario o el texto.")
        if len(texto) > 900:
            raise ValueError("El mensaje es demasiado largo.")
        fila.update(destino=destino[:60], texto=texto)
    else:
        matricula = str(d.get("matricula", "")).strip()
        descripcion = str(d.get("descripcion", "")).strip()
        if not matricula or not descripcion:
            raise ValueError("Falta la matricula o la descripcion.")
        fila.update(matricula=matricula[:20], descripcion=descripcion[:900],
                    prioridad=str(d.get("prioridad", "normal"))[:20])

    escribe(f"COLA#{ident}", fila)
    return r(202, {"ok": True, "id": ident, "estado": "en cola"})


def guarda_alarma(evento, usuario):
    d = cuerpo(evento)
    ident = str(d.get("id") or secrets.token_hex(6))[:40]
    if not d.get("nombre") or not d.get("fuente"):
        raise ValueError("Una alarma necesita nombre y fuente.")
    escribe(f"ALARMA#{ident}", {
        "nombre": str(d["nombre"])[:120],
        "fuente": str(d["fuente"])[:60],
        "campo": str(d.get("campo", ""))[:60],
        "comparacion": str(d.get("comparacion", ">"))[:4],
        "umbral": float(d.get("umbral", 0)),
        "canal": [x for x in (d.get("canal") or ["correo"]) if x in ("correo", "whatsapp")],
        "destinos": [str(x)[:120] for x in (d.get("destinos") or [])][:20],
        "silencio": d.get("silencio") or {"desde": 22, "hasta": 7},
        "perfil": str(d.get("perfil", "interno"))[:40],
        "activa": bool(d.get("activa", True)),
        "creada_por": usuario["correo"],
    })
    return r(200, {"ok": True, "id": ident})


# ----------------------------------------------------------------------
# administracion
# ----------------------------------------------------------------------
def _hay_panel(perfil_id):
    """Si el perfil tiene panel calculado, y de cuando es.

    Los agregados calculan cada noche el panel de cada perfil de esta consola
    que tenga ambito, sumado a lo que diga config/perfiles.json. Uno recien
    creado no lo tiene hasta esa noche, y uno sin ambito no lo tiene nunca: sus
    usuarios entrarian a una pantalla que dice que todavia no hay datos y nadie
    sabria por que.

    Esto lo mira de frente: una cabecera por perfil, que son unos pocos.
    """
    if not perfil_id:
        return {"existe": False}
    try:
        cab = s3.head_object(Bucket=BUCKET, Key=f"cabina/{perfil_id}/panel.json")
        return {"existe": True, "calculado": cab["LastModified"].isoformat()}
    except Exception:
        return {"existe": False}


def administra(evento, metodo, ruta, admin):
    resto = ruta[len("/api/admin/"):]
    d = cuerpo(evento)

    if resto == "usuarios" and metodo == "GET":
        # Con su panel quien tiene delegaciones (docs/65) o clientes y centros
        # recortados (docs/74): el suyo se escribe en la pasada de agregados
        # siguiente a marcarlas, y hasta entonces entra a una pantalla que dice
        # que todavia no hay datos.
        perfiles = {p["_id"]: p for p in lista("PERFIL#")}
        usuarios = lista("USUARIO#")
        for u in usuarios:
            p = perfiles.get(u.get("perfil_id", ""), {"tipo": "cliente"})
            u["delegaciones"] = delegaciones_de(p, u)
            acota = acota_de(u)
            u["clientes"], u["centros"] = acota.get("clientes", []), acota.get("centros", [])
            if u["delegaciones"] or acota:
                u["panel"] = _hay_panel(cabina_y_ambito(u.get("perfil_id", ""), p, u)[0])
        return r(200, {"usuarios": usuarios})

    if resto == "usuarios" and metodo == "POST":
        correo = str(d.get("correo", "")).strip().lower()
        nombre = str(d.get("nombre", "")).strip()
        perfil_id = str(d.get("perfil_id", "")).strip()
        clave = str(d.get("clave", ""))
        if "@" not in correo or not nombre or not perfil_id:
            raise ValueError("Hacen falta nombre, correo y perfil.")
        perfil = lee(f"PERFIL#{perfil_id}")
        if not perfil:
            raise ValueError("Ese perfil no existe.")
        nuevo = not lee(f"USUARIO#{correo}")
        if nuevo:
            if len(clave) < 12:
                raise ValueError("La contrasena inicial necesita 12 caracteres.")
            try:
                cog.admin_create_user(
                    UserPoolId=POOL, Username=correo,
                    UserAttributes=[{"Name": "email", "Value": correo},
                                    {"Name": "email_verified", "Value": "true"}],
                    TemporaryPassword=clave,
                    MessageAction="SUPPRESS",  # la clave la entrega el admin a mano
                )
            except cog.exceptions.UsernameExistsException:
                pass
        escribe(f"USUARIO#{correo}", {
            "nombre": nombre[:80], "perfil_id": perfil_id,
            "estado": "bloqueado" if d.get("estado") == "bloqueado" else "activo",
            "asistente": bool(d.get("asistente", True)),
            "limite_preguntas_dia": max(0, int(d.get("limite_preguntas_dia", 0))),
            "telefono": str(d.get("telefono", ""))[:30],
            # Los cuadrados y las tablas que se le QUITAN dentro de su perfil
            # (docs/61). Vacio = ve lo mismo que su perfil.
            **A.limpia_restricciones(d),
            # Las delegaciones que ve (docs/65), solo del personal: se eligen
            # aqui y no en el perfil. Vacio = todas las de su perfil.
            "delegaciones": delegaciones_de(perfil, d),
            # Los clientes y centros a los que se le recorta lo que ve (docs/74),
            # de cualquier perfil. Vacio = todo lo de su perfil.
            **{k: acota_de(d).get(k, []) for k in ("clientes", "centros")},
            "alta_por": admin["correo"],
        })
        return r(200, {"ok": True, "nuevo": nuevo})

    if resto.startswith("usuarios/") and resto.endswith("/clave") and metodo == "POST":
        correo = resto.split("/")[1].lower()
        clave = str(d.get("clave", ""))
        if len(clave) < 12:
            raise ValueError("La contrasena necesita 12 caracteres.")
        cog.admin_set_user_password(UserPoolId=POOL, Username=correo,
                                   Password=clave, Permanent=False)
        # Darle clave nueva es tambien desbloquearlo: si no, entraria con ella
        # y le contestaria «demasiados intentos» hasta que caducara el contador.
        _limpia_fallos(correo)
        return r(200, {"ok": True, "_nota": "El usuario la cambiara al entrar."})

    if resto.startswith("usuarios/") and metodo == "DELETE":
        correo = resto.split("/", 1)[1].lower()
        if correo == admin["correo"]:
            raise ValueError("No puedes borrar tu propia cuenta.")
        borra(f"USUARIO#{correo}")
        try:
            cog.admin_delete_user(UserPoolId=POOL, Username=correo)
        except Exception:
            pass
        return r(200, {"ok": True})

    if resto == "perfiles" and metodo == "GET":
        return r(200, {
            # Con los cuadrados que ve cada perfil: los que la consola deja
            # quitar a cada uno de sus usuarios (docs/61).
            # El panel del que leen sus usuarios sin delegaciones: el suyo o,
            # del personal sin ambito, el del interno (docs/65).
            "perfiles": [dict(p, panel=_hay_panel(cabina_y_ambito(p.get("_id", ""), p, {})[0]),
                              cuadrados=A.cuadrados_de(p)
                              if A.nivel_de(p.get("tipo", "cliente")) >= A.NIVEL["operaciones"] else [])
                         for p in lista("PERFIL#")],
            # Con el bloque del panel de cada cuadrado y los bloques de cada
            # sesion: el formulario del perfil dice al marcar las sesiones que
            # cuadrados del informe operativo le salen (cuadrados_de).
            "catalogo_cuadrados": {c: {"nombre": A.NOMBRE_CUADRADO[c],
                                       "tablas": dict(A.TABLAS.get(c, {})),
                                       "bloque": bloque,
                                       "solo_direccion": c in A.SOLO_DIRECCION,
                                       "sin_ambito": c in A.SIN_AMBITO,
                                       # Los que llevan al panel: sus paneles (docs/64).
                                       "paneles": {p: A.PANELES_SESION[A.PANEL_DE_CUADRADO[c][0]][p]
                                                   for p in A.PANEL_DE_CUADRADO[c][1]}
                                       if c in A.PANEL_DE_CUADRADO else {}}
                                   for c, bloque in A.CUADRADOS},
            # Lo que se elige en el perfil ademas de los cuadrados.
            "otras_pantallas": list(A.OTRAS_PANTALLAS),
            "catalogo_sesiones": {k: {"nombre": v[0], "minimo": v[1], "bloques": list(v[2]),
                                      "paneles": dict(A.PANELES_SESION.get(k, {}))}
                                  for k, v in A.SESIONES.items()},
            # Las partes del cuadro, para las casillas de «Qué ve en el cuadro».
            "catalogo_cuadro": {k: {"nombre": v[0], "flujos": list(v[1])}
                                for k, v in A.SECCIONES_CUADRO.items()},
            # El techo se envia para que el panel de admin pueda avisar de que
            # un permiso marcado no va a tener efecto en ese tipo de perfil.
            "techo": {k: sorted(v) for k, v in A.TECHO.items()},
            # Y el orden de los tipos, para que la consola sepa que una sesion
            # de «operaciones» no se le puede dar a un perfil de cliente sin
            # tener que llevar esa escalera escrita por su cuenta.
            "niveles": A.NIVEL,
            "implicitos": {k: sorted(v) for k, v in A.IMPLICITOS.items()},
        })

    if resto == "perfiles" and metodo == "POST":
        pid = str(d.get("perfil_id", "")).strip()[:40]
        tipo = str(d.get("tipo", "cliente"))
        if not pid or tipo not in A.TECHO:
            raise ValueError("Perfil o tipo no validos.")
        amb = d.get("ambito") or {}
        sesiones = [s for s in (d.get("sesiones") or []) if s in A.SESIONES]
        paneles_ocultos = A.paneles_ocultos(d)
        # Elegido cuadrado a cuadrado (docs/64): los que llevan al panel dan su
        # sesion, y los paneles de los que no se eligen se quitan.
        cuadrados = None
        if isinstance(d.get("cuadrados"), list):
            cuadrados = [c for c, _ in A.CUADRADOS if c in d["cuadrados"]]
            for c, (sesion, paneles) in A.PANEL_DE_CUADRADO.items():
                if c in cuadrados and sesion not in sesiones:
                    sesiones.append(sesion)
            elegidos = {p for c in cuadrados for p in A.PANEL_DE_CUADRADO.get(c, ("", ()))[1]}
            quitados = {p for c, (_, ps) in A.PANEL_DE_CUADRADO.items() if c not in cuadrados
                        for p in ps if p not in elegidos}
            paneles_ocultos = A.paneles_ocultos({"paneles_ocultos": paneles_ocultos + sorted(quitados)})
        extra = {} if cuadrados is None else {"cuadrados": cuadrados}
        # Las delegaciones ya no son del perfil sino de cada usuario (docs/65).
        # Las que tuviera de antes pasan a sus usuarios que no tengan ninguna,
        # para que guardar el perfil no le cambie a nadie lo que ve.
        antes = lee(f"PERFIL#{pid}") or {}
        heredadas = [str(x)[:80] for x in ((antes.get("ambito") or {}).get("delegaciones") or [])][:200]
        if heredadas and tipo != "cliente":
            for u in lista("USUARIO#"):
                if u.get("perfil_id") == pid and not delegaciones_de({"tipo": tipo}, u):
                    correo_u = u.pop("_id")
                    escribe(f"USUARIO#{correo_u}", dict(u, delegaciones=sorted(set(heredadas))))
        escribe(f"PERFIL#{pid}", {
            **extra,
            "nombre": str(d.get("nombre", pid))[:80],
            "tipo": tipo,
            "ambito": {**{k: [str(x)[:80] for x in (amb.get(k) or [])][:200]
                          for k in ("clientes", "centros")}, "delegaciones": []},
            "sesiones": [s for s in A.SESIONES if s in sesiones],
            "paneles": [str(x)[:40] for x in (d.get("paneles") or [])][:64],
            # Las partes del cuadro que se le QUITAN; vacio = las ve todas.
            "cuadro_ocultas": [s for s in (d.get("cuadro_ocultas") or [])
                               if s in A.SECCIONES_CUADRO],
            # Y los paneles de /panel/ que se le QUITAN (docs/63), y las tablas
            # de cada cuadrado (docs/64).
            "paneles_ocultos": paneles_ocultos,
            "tablas_ocultas": A._tablas_validas(d.get("tablas_ocultas")),
            # Se guarda lo que marque el admin; el techo se aplica al servir.
            "permisos": {k: bool(v) for k, v in (d.get("permisos") or {}).items()},
            "reglas_negocio": d.get("reglas_negocio") or {},
            "creado_por": admin["correo"],
        })
        return r(200, {
            "ok": True, "id": pid,
            "permisos_efectivos": sorted(
                p for p, v in (d.get("permisos") or {}).items()
                if v and p in A.TECHO.get(tipo, set())),
            "ignorados": sorted(
                p for p, v in (d.get("permisos") or {}).items()
                if v and p not in A.TECHO.get(tipo, set())),
        })

    if resto.startswith("perfiles/") and metodo == "DELETE":
        pid = resto.split("/", 1)[1]
        if any(u.get("perfil_id") == pid for u in lista("USUARIO#")):
            raise ValueError("Hay usuarios con ese perfil: cambialos antes.")
        borra(f"PERFIL#{pid}")
        return r(200, {"ok": True})

    if resto == "config" and metodo == "GET":
        return r(200, config())

    if resto == "config" and metodo == "PUT":
        c = config()
        if "asistente_global" in d:
            c["asistente_global"] = bool(d["asistente_global"])
        if "limite_preguntas_dia" in d:
            c["limite_preguntas_dia"] = max(0, int(d["limite_preguntas_dia"]))
        if "umbral_rentabilidad_mes" in d:
            c["umbral_rentabilidad_mes"] = float(d["umbral_rentabilidad_mes"])
        # El modelo del asistente (docs/78). Vacio = el de la variable MODELO.
        if "asistente_modelo" in d:
            m = str(d["asistente_modelo"] or "")
            if m and m not in A.MODELOS_ASISTENTE:
                raise ValueError("Ese modelo no esta entre los del asistente.")
            c["asistente_modelo"] = m
        escribe("CONFIG", c, "GLOBAL")
        return r(200, c)

    if resto == "telefonos" and metodo == "GET":
        return r(200, {"telefonos": lista("TELEFONO#")})

    if resto == "telefonos" and metodo == "POST":
        eid = str(d.get("empleado_id", "")).strip()[:20]
        tel = str(d.get("telefono", "")).strip()
        if not eid or not tel.startswith("+"):
            raise ValueError("Hace falta el id del empleado y un telefono con prefijo (+34...).")
        escribe(f"TELEFONO#{eid}", {
            "nombre": str(d.get("nombre", ""))[:80],
            "telefono": tel[:20],
            "oficio": str(d.get("oficio", "reponedor"))[:20],
            "alta_por": admin["correo"],
        })
        return r(200, {"ok": True})

    if resto.startswith("telefonos/") and metodo == "DELETE":
        borra("TELEFONO#" + resto.split("/", 1)[1])
        return r(200, {"ok": True})

    if resto == "telemetria" and metodo == "GET":
        return r(200, {"ficheros": {f["_id"]: f for f in lista("TELEMETRIA#")},
                       "tipos": {t: TE.NOMBRE[t] for t in TE.TIPOS}})

    if resto == "telemetria" and metodo == "POST":
        return sube_telemetria(d, admin)

    if resto == "cola" and metodo == "GET":
        return r(200, {"cola": lista("COLA#")[-100:]})

    return r(404, {"error": "No existe esa ruta de administracion."})


# ----------------------------------------------------------------------
# los ficheros de telemetria (docs/53)
# ----------------------------------------------------------------------
def sube_telemetria(d, admin):
    """Un fichero de Nayax, Prodelfi, Nebula o grupos, subido desde la consola.

    Se lee AQUI, al subirlo, y no de noche: si no es el fichero que tiene que
    ser, quien lo sube se entera en el acto y con el motivo, no a la manana
    siguiente con un cuadrado vacio. Se guarda el original tal cual (para poder
    volver a leerlo si cambian las reglas) y lo leido, que es lo que usa la
    noche. El ultimo de cada sistema sustituye al anterior.
    """
    import base64
    import re as _re

    nombre = str(d.get("nombre", "")).strip()[:120] or "fichero"
    try:
        datos = base64.b64decode(str(d.get("contenido", "")), validate=True)
    except Exception:
        raise ValueError("El fichero no ha llegado bien. Vuelve a subirlo.")
    if len(datos) > MAX_FICHERO:
        raise ValueError(f"El fichero pasa de {MAX_FICHERO // 1048576} MB.")
    try:
        tipo, filas, resumen = TE.lee(datos)
    except TE.FicheroNoValido as e:
        raise ValueError(str(e))
    except Exception as e:  # noqa: BLE001
        print(f"ERROR leyendo {nombre}: {type(e).__name__}: {e}")
        raise ValueError("No se ha podido leer el fichero. ¿Es el .xlsx, .xls o .csv tal cual "
                         "sale del sistema?")
    ahora = datetime.datetime.utcnow().replace(microsecond=0)
    sello = ahora.strftime("%Y%m%dT%H%M%S")
    limpio = _re.sub(r"[^A-Za-z0-9._-]+", "_", nombre)[-80:]
    original = f"{EXTERNO}/{tipo}/originales/{sello}-{limpio}"
    s3.put_object(Bucket=BUCKET, Key=original, Body=datos,
                  ContentType="application/octet-stream", ServerSideEncryption="AES256")
    ficha = {"tipo": tipo, "nombre": nombre, "subido": ahora.isoformat() + "Z",
             "por": admin["correo"], "resumen": resumen, "original": original}
    s3.put_object(Bucket=BUCKET, Key=f"{EXTERNO}/{tipo}/actual.json",
                  Body=json.dumps(dict(ficha, filas=filas), ensure_ascii=False,
                                  separators=(",", ":")).encode("utf-8"),
                  ContentType="application/json", ServerSideEncryption="AES256")
    escribe(f"TELEMETRIA#{tipo}", ficha)
    return r(200, {"ok": True, "tipo": tipo, "nombre_tipo": TE.NOMBRE[tipo], "ficha": ficha,
                   "_nota": "Se cruza con el censo esta noche, con los agregados (4:45)."})
